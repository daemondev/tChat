﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Web.WebSockets;

namespace MSWSChat
{
    public class MyWSHandler : WebSocketHandler
    {
        public override void OnOpen()
        {
            this.Send("Welcom from " + this.WebSocketContext.UserHostAddress);
        }

        public override void OnMessage(string message)
        {
            string msgBack = string.Format(
                "You have sent {0} at {1}", message, DateTime.Now.ToLongTimeString());
            this.Send(msgBack);
        }

        public override void OnClose()
        {
            base.OnClose();
        }

        public override void OnError()
        {
            base.OnError();
        }
    }
}