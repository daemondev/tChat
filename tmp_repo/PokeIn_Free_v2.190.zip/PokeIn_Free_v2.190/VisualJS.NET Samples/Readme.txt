1 - Install the setup
2 - Extract the zip file and open the solution file under the Visual Studio