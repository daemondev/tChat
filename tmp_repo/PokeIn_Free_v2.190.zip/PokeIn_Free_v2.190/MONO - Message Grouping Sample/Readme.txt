Open this project under MonoDevelop / Mono Runtime Enabled

You can run all the other samples using PokeIn's Mono Library!